package com.example.hikodproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
