import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.redAccent),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'UI App with Flutter'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? message; // To store the message
  Color messageColor = Colors.black;

  void showMessage() {
    setState(() {
      message = "demo";
      messageColor = Colors.red;
    });
  }
  void clearMessage() {
    setState(() {
      message = null; // Clear the message by setting it to null
    });
  }
  void showDialogButton(){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Dialog Title'),
          content: Container(
            width: 150,
            height: 150,
            child: const Center(
              child: Text('This is dialog box.'),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text("UI App with Flutter",style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0),),
        leading: Builder(
          builder: (context)=> IconButton(
            icon: const Icon(
              Icons.menu,
              color: Colors.black,
            ),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),),

        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.black,
            ),
            onPressed: () {
            },
          ),
          IconButton(
            icon: const Icon(
              Icons.settings,
              color: Colors.black,
            ),
            onPressed: () {
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children:[
            Container(
              color: Colors.redAccent,
              height: 200,
              alignment: Alignment.center,
              child: const Text('Drawer Header', style: TextStyle(color: Colors.black, fontSize: 23, fontWeight: FontWeight.bold,),),
            ),
            ListTile(
              title: const Text('Item 1'),
              onTap: () {
              },
            ),
            ListTile(
              title: const Text('Item 2'),
              onTap: () {
              },
            ),
          ],
        ),
      ),

      body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Container(
              height: 20,
            ),
            const Text(
              'Welcome to my App!',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0),
            ),
            Container(
              height: 20,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    const Text(
                      "Widget 1",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
                    ),
                    Container(
                      height:100,
                      width: 100,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red,
                      ),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                      ),
                      onPressed: () {
                        showMessage();
                      },
                      child: const Text('Open Text Button'),
                    ),

                    const SizedBox(height: 20),

                  ],
                ),
                Column(
                  children: [
                    const Text(
                      "Widget 2",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
                    ),
                    Container(
                      height:100,
                      width: 100,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red,
                      ),
                    ),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                      ),
                      onPressed: () {
                        clearMessage();
                      },
                      child: const Text('Close Text Button'),
                    ),
                  ],
                ),
              ],
            ),

            if (message != null) // Check if message is not null
              Text(
                message!,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: messageColor ),
              ),
            const SizedBox(
              height: 20,
            ),
            const Text(
              'This is my first app!',
              style: TextStyle(fontSize: 23.0),
            ),
          ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: (){
          showDialogButton();
        }
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
